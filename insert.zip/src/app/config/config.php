<?php
return [
    "" => "HomeController:index",
    "home" => "HomeController:index",
    "edit" => "HomeController:edit", // имя класса=> метод
    "home/edit" => "HomeController:edit",
    "admin" => "AdminController:index",
    "admin/home" => "AdminController:index",
    "admin/home/edit" => "AdminController:edit",
    "user" => "UsersController:index",
    "user/edit" => "UsersController:edit",

];