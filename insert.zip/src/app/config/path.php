<?php


return [

    'views' => __DIR__ . "/../../views/",
];