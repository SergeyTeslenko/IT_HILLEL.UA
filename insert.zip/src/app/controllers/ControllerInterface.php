<?php

namespace Application\App\Controllers;

interface ControllerInterface
{
    public function index();
}