<?php


return [

    'name' => 'Sergey Teslenko Engine',
    'locale' => 'ru',

    'fallback_locale' => 'ru',


];