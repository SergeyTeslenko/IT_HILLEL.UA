<?php

return [
    'host' => '127.0.0.1',
    'database' => 'app',
    'username' => 'root',
    'password' => '',
];