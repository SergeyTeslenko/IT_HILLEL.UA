<?php


return [

    'views' => __DIR__ . "/../views/",
    'namespace' => "Application\\App\\Controllers\\"
];