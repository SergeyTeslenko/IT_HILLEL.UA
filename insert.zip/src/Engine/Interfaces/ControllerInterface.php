<?php

namespace Application\Engine\Interfaces;

interface ControllerInterface
{
    public function index();
}